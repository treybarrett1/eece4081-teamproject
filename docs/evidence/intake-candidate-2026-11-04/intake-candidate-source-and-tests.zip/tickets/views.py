import json

from django.contrib.auth import authenticate, login, logout
from django.core.exceptions import PermissionDenied, ValidationError
from django.http import HttpResponse, JsonResponse
from django.middleware.csrf import get_token
from django.views.decorators.http import require_GET, require_http_methods, require_POST

from tickets.services import create_ticket, public_ticket, visible_tickets


def parse_body(request):
    try:
        return json.loads(request.body)
    except (ValueError, UnicodeDecodeError) as error:
        raise ValidationError({"body": "Expected valid JSON"}) from error


@require_GET
def csrf(request):
    return JsonResponse({"csrf_token": get_token(request)})


@require_POST
def sign_in(request):
    try:
        data = parse_body(request)
        if not isinstance(data, dict):
            raise ValidationError({"body": "Expected an object"})
    except ValidationError as error:
        return JsonResponse({"errors": error.message_dict}, status=400)
    username, password = data.get("username"), data.get("password")
    actor = None
    if isinstance(username, str) and isinstance(password, str):
        actor = authenticate(request, username=username, password=password)
    if actor is None:
        return JsonResponse({"error": "Invalid credentials"}, status=403)
    login(request, actor)
    return JsonResponse({"signed_in": True})


@require_POST
def sign_out(request):
    logout(request)
    return HttpResponse(status=204)


@require_http_methods(["GET", "POST"])
def collection(request):
    if not request.user.is_authenticated:
        return JsonResponse({"error": "Sign in required"}, status=401)
    try:
        if request.method == "POST":
            ticket = create_ticket(request.user, parse_body(request))
            return JsonResponse(public_ticket(ticket), status=201)
        return JsonResponse(
            {"tickets": [public_ticket(t) for t in visible_tickets(request.user)]}
        )
    except ValidationError as error:
        return JsonResponse({"errors": error.message_dict}, status=400)
    except PermissionDenied:
        return JsonResponse({"error": "Not permitted"}, status=403)


@require_GET
def detail(request, ticket_id):
    if not request.user.is_authenticated:
        return JsonResponse({"error": "Sign in required"}, status=401)
    try:
        ticket = visible_tickets(request.user).filter(pk=ticket_id).first()
    except PermissionDenied:
        return JsonResponse({"error": "Not permitted"}, status=403)
    if ticket is None:
        return JsonResponse({"error": "Not found"}, status=404)
    return JsonResponse(public_ticket(ticket))
