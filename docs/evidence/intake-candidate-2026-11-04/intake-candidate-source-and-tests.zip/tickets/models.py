import uuid

from django.conf import settings
from django.db import models

CATEGORIES = ("Hardware", "Software", "Network", "Access", "Other")
IMPACTS = ("One user", "Multiple users", "Organization-wide")


class Ticket(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    requester = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    title = models.CharField(max_length=120)
    description = models.TextField()
    category = models.CharField(max_length=20, choices=[(x, x) for x in CATEGORIES])
    impact = models.CharField(max_length=30, choices=[(x, x) for x in IMPACTS])
    status = models.CharField(max_length=20, default="New", editable=False)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="assigned_tickets",
    )
    priority = models.CharField(max_length=10, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
