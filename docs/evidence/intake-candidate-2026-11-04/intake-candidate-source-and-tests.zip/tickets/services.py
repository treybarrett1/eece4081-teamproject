"""Shared intake/read authorization; no lifecycle or history implementation yet."""

from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction

from tickets.models import CATEGORIES, IMPACTS, Ticket

ROLES = {"Requester", "Support", "Developer", "Administrator"}


def current_role(actor):
    if not actor.is_authenticated:
        raise PermissionDenied("Not permitted")
    current = get_user_model().objects.filter(pk=actor.pk, is_active=True).first()
    if current is None:
        raise PermissionDenied("Not permitted")
    roles = set(current.groups.values_list("name", flat=True))
    if len(roles) != 1 or not roles <= ROLES:
        raise PermissionDenied("Not permitted")
    return next(iter(roles))


@transaction.atomic
def create_ticket(actor, payload):
    if current_role(actor) != "Requester":
        raise PermissionDenied("Not permitted")
    if not isinstance(payload, dict):
        raise ValidationError({"body": "Expected an object"})
    allowed = {"title", "description", "category", "impact"}
    errors = {key: "Field cannot be supplied" for key in payload.keys() - allowed}
    clean = {}
    for field, limit in (("title", 120), ("description", 4000)):
        value = payload.get(field)
        if not isinstance(value, str) or not 1 <= len(value.strip()) <= limit:
            errors[field] = f"Use 1 to {limit} characters after trimming"
        else:
            clean[field] = value.strip()
    for field, choices in (("category", CATEGORIES), ("impact", IMPACTS)):
        value = payload.get(field)
        if not isinstance(value, str) or value not in choices:
            errors[field] = "Choose an allowed value"
        else:
            clean[field] = value
    if errors:
        raise ValidationError(errors)
    ticket = Ticket(requester=actor, **clean)
    ticket.full_clean()
    ticket.save()
    return ticket


def visible_tickets(actor):
    role = current_role(actor)
    if role == "Requester":
        return Ticket.objects.filter(requester_id=actor.pk).order_by("created_at", "id")
    if role == "Support":
        return Ticket.objects.all().order_by("created_at", "id")
    raise PermissionDenied("Not permitted")


def public_ticket(ticket):
    return {
        "id": str(ticket.id),
        "title": ticket.title,
        "description": ticket.description,
        "category": ticket.category,
        "impact": ticket.impact,
        "status": ticket.status,
        "owner": ticket.owner_id,
        "priority": ticket.priority,
        "created_at": ticket.created_at.isoformat(),
    }
