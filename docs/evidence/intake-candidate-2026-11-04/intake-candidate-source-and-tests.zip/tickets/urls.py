from django.urls import path

from tickets import views

urlpatterns = [
    path("session/csrf", views.csrf),
    path("session/sign-in", views.sign_in),
    path("session/sign-out", views.sign_out),
    path("tickets", views.collection),
    path("tickets/<uuid:ticket_id>", views.detail),
]
