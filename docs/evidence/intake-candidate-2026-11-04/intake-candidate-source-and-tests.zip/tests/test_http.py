import uuid

import pytest
from django.test import Client

from tickets.models import Ticket
from tickets.services import create_ticket

pytestmark = pytest.mark.django_db


def token(client):
    return client.get("/session/csrf").json()["csrf_token"]


def test_real_login_csrf_create_read_isolation_and_logout(actors, payload):
    client = Client(enforce_csrf_checks=True)
    assert client.post("/session/sign-in", {"username": "alice"}).status_code == 403
    response = client.post(
        "/session/sign-in",
        {"username": "alice", "password": "synthetic-test-password"},
        content_type="application/json",
        HTTP_X_CSRFTOKEN=token(client),
    )
    assert response.status_code == 200
    csrf = token(client)
    response = client.post(
        "/tickets", payload, content_type="application/json", HTTP_X_CSRFTOKEN=csrf
    )
    assert response.status_code == 201
    item = response.json()
    assert client.get("/tickets").json()["tickets"] == [item]
    assert client.get("/tickets/" + item["id"]).json() == item
    assert Ticket.objects.get(pk=item["id"]).requester == actors["alice"]
    client.force_login(actors["bob"])
    foreign = client.get("/tickets/" + item["id"])
    missing = client.get("/tickets/" + str(uuid.uuid4()))
    assert foreign.status_code == missing.status_code == 404
    assert foreign.json() == missing.json()
    assert client.get("/tickets").json() == {"tickets": []}
    assert (
        client.post("/session/sign-out", HTTP_X_CSRFTOKEN=token(client)).status_code
        == 204
    )
    assert client.get("/tickets").status_code == 401
    assert client.get("/tickets/" + item["id"]).status_code == 401


@pytest.mark.parametrize(
    "data",
    [
        {"username": "alice", "password": "wrong"},
        {"username": "missing", "password": "wrong"},
        {"username": [], "password": 1},
        {},
    ],
)
def test_login_failures_are_uniform(actors, client, data):
    response = client.post("/session/sign-in", data, content_type="application/json")
    assert response.status_code == 403
    assert response.json() == {"error": "Invalid credentials"}


def test_disabled_login_and_existing_session(actors, client, payload):
    client.force_login(actors["alice"])
    actors["alice"].is_active = False
    actors["alice"].save()
    assert client.get("/tickets").status_code == 401
    response = client.post(
        "/session/sign-in",
        {"username": "alice", "password": "synthetic-test-password"},
        content_type="application/json",
    )
    assert response.status_code == 403


@pytest.mark.parametrize(
    "path,body",
    [
        ("/session/sign-in", "{"),
        ("/session/sign-in", "[]"),
        ("/tickets", "{"),
        ("/tickets", "[]"),
        ("/tickets", "{}"),
    ],
)
def test_bad_json_and_fields_are_rejected(actors, client, path, body):
    client.force_login(actors["alice"])
    response = client.post(path, body, content_type="application/json")
    assert response.status_code == 400 and "errors" in response.json()
    assert not Ticket.objects.exists()


@pytest.mark.parametrize("name", ["dev", "admin"])
def test_restricted_role_read_and_write_denied(actors, client, payload, name):
    ticket = create_ticket(actors["alice"], payload)
    client.force_login(actors[name])
    assert client.get("/tickets").status_code == 403
    assert client.get("/tickets/" + str(ticket.pk)).status_code == 403
    assert (
        client.post("/tickets", payload, content_type="application/json").status_code
        == 403
    )


def test_support_reads_all_but_cannot_submit(actors, client, payload):
    ticket = create_ticket(actors["alice"], payload)
    client.force_login(actors["support"])
    assert len(client.get("/tickets").json()["tickets"]) == 1
    assert client.get("/tickets/" + str(ticket.pk)).status_code == 200
    assert (
        client.post("/tickets", payload, content_type="application/json").status_code
        == 403
    )


def test_anonymous_write_and_unsupported_method(client, payload):
    assert (
        client.post("/tickets", payload, content_type="application/json").status_code
        == 401
    )
    assert client.delete("/tickets").status_code == 405


def test_script_text_is_json_not_html(actors, client, payload):
    client.force_login(actors["alice"])
    payload["title"] = "<script>alert(1)</script>"
    response = client.post("/tickets", payload, content_type="application/json")
    assert response.status_code == 201
    assert response["Content-Type"] == "application/json"
    assert response.json()["title"] == payload["title"]
