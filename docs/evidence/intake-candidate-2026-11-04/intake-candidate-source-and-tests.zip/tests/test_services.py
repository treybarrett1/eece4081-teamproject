from unittest.mock import patch

import pytest
from django.contrib.auth.models import AnonymousUser, Group
from django.core.exceptions import PermissionDenied, ValidationError

from tickets.models import Ticket
from tickets.services import create_ticket, current_role, public_ticket, visible_tickets

pytestmark = pytest.mark.django_db


def test_create_defaults_and_persistent_round_trip(actors, payload):
    payload["title"] = "  Example  "
    one = create_ticket(actors["alice"], payload)
    two = create_ticket(actors["alice"], payload)
    saved = Ticket.objects.get(pk=one.pk)
    assert saved.title == "Example"
    assert saved.pk != two.pk
    assert saved.requester == actors["alice"]
    assert saved.status == "New" and saved.owner is None and saved.priority is None
    assert saved.created_at.utcoffset().total_seconds() == 0
    assert public_ticket(saved)["id"] == str(saved.pk)


@pytest.mark.parametrize(
    "field,value",
    [
        ("title", ""),
        ("title", "  "),
        ("title", "x" * 121),
        ("title", 3),
        ("description", ""),
        ("description", "x" * 4001),
        ("category", "Unknown"),
        ("category", []),
        ("impact", "Unknown"),
        ("impact", None),
        ("requester", 999),
        ("status", "Closed"),
        ("owner", 1),
        ("priority", "Critical"),
    ],
)
def test_bad_input_creates_nothing(actors, payload, field, value):
    payload[field] = value
    with pytest.raises(ValidationError) as error:
        create_ticket(actors["alice"], payload)
    assert field in error.value.message_dict
    assert Ticket.objects.count() == 0


@pytest.mark.parametrize("field,limit", [("title", 120), ("description", 4000)])
def test_exact_text_boundary_is_accepted(actors, payload, field, limit):
    payload[field] = "x" * limit
    assert len(getattr(create_ticket(actors["alice"], payload), field)) == limit


def test_non_object_and_missing_fields(actors):
    for data in ([], {}, {"title": "ok"}):
        with pytest.raises(ValidationError):
            create_ticket(actors["alice"], data)
    assert Ticket.objects.count() == 0


@pytest.mark.parametrize("name", ["support", "dev", "admin"])
def test_non_requester_cannot_create(actors, payload, name):
    with pytest.raises(PermissionDenied):
        create_ticket(actors[name], payload)
    assert not Ticket.objects.exists()


def test_visibility_respects_current_role_and_ownership(actors, payload):
    one = create_ticket(actors["alice"], payload)
    two = create_ticket(actors["bob"], payload)
    assert list(visible_tickets(actors["alice"])) == [one]
    assert list(visible_tickets(actors["support"])) == [one, two]
    for name in ("dev", "admin"):
        with pytest.raises(PermissionDenied):
            visible_tickets(actors[name])


def test_disabled_missing_and_ambiguous_roles_are_denied(actors):
    with pytest.raises(PermissionDenied):
        current_role(AnonymousUser())
    user = actors["alice"]
    user.is_active = False
    user.save()
    with pytest.raises(PermissionDenied):
        current_role(user)
    user.is_active = True
    user.save()
    user.groups.clear()
    with pytest.raises(PermissionDenied):
        current_role(user)
    user.groups.add(
        Group.objects.get(name="Requester"), Group.objects.get(name="Support")
    )
    with pytest.raises(PermissionDenied):
        current_role(user)
    user.groups.clear()
    user.groups.add(Group.objects.create(name="Unknown"))
    with pytest.raises(PermissionDenied):
        current_role(user)


def test_database_failure_leaves_no_partial_ticket(actors, payload):
    original = Ticket.save

    def insert_then_fail(ticket, *args, **kwargs):
        original(ticket, *args, **kwargs)
        raise RuntimeError("synthetic failure after insert")

    with patch.object(Ticket, "save", insert_then_fail):
        with pytest.raises(RuntimeError):
            create_ticket(actors["alice"], payload)
    assert Ticket.objects.count() == 0
