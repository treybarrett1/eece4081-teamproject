import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group


@pytest.fixture(autouse=True)
def fast_test_passwords(settings):
    # Test speed only; runtime retains Django's normal password hashers.
    settings.PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]


@pytest.fixture
def actors(db):
    result = {}
    for name, role in (
        ("alice", "Requester"),
        ("bob", "Requester"),
        ("support", "Support"),
        ("dev", "Developer"),
        ("admin", "Administrator"),
    ):
        actor = get_user_model().objects.create_user(
            username=name, password="synthetic-test-password"
        )
        actor.groups.add(Group.objects.get_or_create(name=role)[0])
        result[name] = actor
    return result


@pytest.fixture
def payload():
    return {
        "title": "Network issue",
        "description": "Synthetic demonstration ticket",
        "category": "Network",
        "impact": "One user",
    }
