# Amendment 1: assignment guide and review packet

Prepared for Austin, November 4, 2026. Status: completed proposal and validated diff; evidence-dependent grading requirements remain unresolved.

## What the professor is asking for

Update the team's existing working agreement based on experience. Submit a diff against v0.3, explain every change, connect at least one change to a named Sprint 1 incident, and commit to a numeric coverage minimum for an explicitly named scope. Explain the number using the actual team's coverage report. The rubric totals 15 points (2 + 3 + 4 + 3 + 3).

The first screenshot is the assignment authority. The second is a prior assistant's progress report, not an additional professor requirement. Its request to upload coverage was advice about missing evidence, not something you must obey to use this packet. Its warning about the separate prototype's 89% is supported by the saved PR record. Its claim that Team1 was inaccessible is superseded by the later saved handoff packet, which includes a Team1 documentation snapshot and CI artifacts. Live GitHub pages could not be retrieved in this session; conclusions here use those local records, not a fresh repository inspection.

## What is prepared

1. `Amendment1-against-v0.3.diff`: the requested submission format, with rationales embedded alongside the policy changes.
2. `PLAYBOOK-Amendment1-PROPOSED.md`: the full readable result for review. The diff is the primary assignment artifact.
3. `VALIDATION.txt`: successful patch check, actual application to a disposable copy, exact result comparison and baseline verification.
4. `AI-SESSION-NOTE.md`: disclosure to help prepare the team's required AI-use log.

The original handoff and snapshot are unchanged. Nothing was adopted, pushed, sent to teammates or submitted to the course portal.

## Recommended decision

Propose **60% aggregate statement coverage across the first-party Team1 Python/Django application runtime** for the rest of the semester. This includes product models, request handling, services, permissions, validation, configuration and entry points. It excludes tests, documentation helpers, gate fixtures, dependencies and generated migrations; manually written migration logic stays included. It is neither whole-repository coverage nor a domain-only/per-file requirement. Actual module paths must be inventoried once source is available.

This is a conservative workload judgment, not a measured baseline or an objectively optimal threshold. Compared with a more ambitious target, it leaves more room for uneven availability and integration work while still requiring a majority of executable statements to be exercised. It can still be above the unknown current result. No positive percentage can be guaranteed achievable without seeing the code and tests. A 60% aggregate result can also conceal badly tested individual files, so the amendment retains behavior-specific review requirements for ticket permissions, lifecycle, validation and persistence.

Do not use 89% to calculate headroom. PR #18 reports that result only for a separate prototype. The actual saved Team1 CI evidence says product tests were not applicable because no tracked application/test source existed. That is **coverage unavailable**, not a measured 0% result. The chosen 60% cannot truthfully earn the rubric's actual-report justification points on present evidence.

## Named incident and rationale map

| Change | Reason and evidence |
| --- | --- |
| A1: submission receipt required before closing a course handoff | **T4 submission-confirmation gap, personal-repository issue #14.** Doc's final comment linked merged scope commit `9ac80e1` while stating portal confirmation was pending. The saved issue is closed. Section 2 of v0.3 required a smoke check and merged PR link, which establish readiness but not receipt. The separate T3/T4 checklist already required confirmation; the failure was also inconsistent enforcement. Do not claim T4 was never submitted. Confirm this is a course-defined Sprint 1 incident. |
| A2: 60% and explicit application scope | Replaces indefinite deferral with a modest, auditable semester commitment; avoids mixing helper/test coverage with product coverage. The rationale is explicitly a planning assumption. |
| A3: scope inventory, matching measurement, failure rules and retained reports | Prevents green documentation/fixture CI or missing source from being mistaken for product coverage. These are proposed obligations; this document patch does not configure CI. |
| A4: version entry | Records the amendment and its limitations without rewriting historical v0.3 results. |

## Steps to finish and submit

1. **Review the diff with the group.** Confirm that v0.3 at saved Team1 commit `ba34d08711ff64aa4cfe484a16013ed2d6971bb4` is the professor's intended baseline. Use the complete rationale text already in the diff.
2. **Confirm Sprint 1 relevance.** The T4 final comment is dated September 28 in America/Chicago; the issue closed October 21. v0.3 describes weekly sprints beginning September 14, so dates alone do not prove this is the assignment's Sprint 1. If it is outside the course-defined Sprint 1, replace A1's incident with a genuine in-sprint event, retaining what happened, the actual old rule, why it failed and the remedy. Do not relabel dates or invent an event.
3. **Locate the real implementation and tests when possible.** A teammate or instructor may be able to provide a report even if you cannot run the application. Ask for the tested commit, command, scope/configuration, per-file coverage table and TOTAL, test results and coverage.xml. No need to substitute the personal prototype.
4. **If access remains unavailable, keep the disclosure.** Present 60% as the requested best-judgment recommendation and explain that the actual-report requirement is unresolved. Tell the instructor that the available Team1 snapshot is documentation-only. Submitting this honest proposal may receive partial credit; it cannot guarantee the report-based criterion.
5. **When source is available, validate the proposal.** Inventory actual runtime paths in `docs/COVERAGE_SCOPE.md`, configure statement coverage including unimported modules, review omissions, run actual tests and inspect uncovered behavior. A baseline below 60% means the team must add meaningful tests before claiming compliance or openly reconsider the proposed policy through the existing procedure; it does not authorize claiming the floor already holds.
6. **Implement enforcement separately.** Update local and CI pytest commands with the reviewed coverage configuration and `--cov-fail-under=60`. Preserve full reports and exact revisions. The proposed playbook gives the obligations; no executable CI changes were made because actual product paths and environment are unknown. Existing required-status-check protection is also not verified as active.
7. **Record review and adoption.** Follow the existing policy-change rule: strict team majority and at least one non-author review. Complete the AI log using the session note and this chat; do not claim assistant verification is teammate approval.
8. **Submit the diff and retain receipt.** Include the readable copy and evidence note if the portal allows supporting files. Name an acknowledged submitter; record the submitted version, confirmation time/time zone and sanitized receipt reference. Keep the handoff open until confirmed.

## Rubric check

| Criterion | Present status |
| --- | --- |
| Diff against v0.3 (2) | Prepared and mechanically verified against the saved exact baseline. |
| Rationale for every change (3) | A1–A4 included in the amended text and above. Human review pending. |
| Named Sprint 1 incident (4) | Specific documented incident supplied; Sprint 1 classification must be confirmed or replaced. |
| Numeric and scoped floor (3) | Proposed 60.00% aggregate application-runtime statement coverage; actual path mapping pending. |
| Actual coverage report supports number (3) | Unmet: no Team1 product report exists in the available packet. Explicitly disclosed. |

## Evidence used

All paths below are relative to `../EECE_4081_Austin-Amendment1-Handoff/`:

- `PLAYBOOK-v0.3-Team1.md`, compared byte for byte with the saved repository snapshot's `docs/PLAYBOOK.md`.
- `T4-issue14-record.json` and `T4-issue14-comments.json`: closed state and pending-confirmation comment. [Original incident comment](https://github.com/treybarrett1/eece4081-teamproject/issues/14#issuecomment-5883457926).
- `T3_T4_SUBMISSION_HANDOFF-Team1.md`: existing confirmation requirements and pending completion fields.
- `prototype-pr18-record.json`: explicitly separate prototype. [Original PR](https://github.com/treybarrett1/eece4081-teamproject/pull/18).
- `Team1-CI-evidence/gate-evidence/scope.json`, `application-tests.txt` and `revision.txt`: no product scope or product test result at the saved commit. [Referenced saved CI run](https://github.com/eece-4081-fall-2026/Team1/actions/runs/39694383194).

These links identify the provenance of local records; they were not independently fetched successfully in this session.
